
import { useState } from 'react';
import './App.css';


const App = () => {
  const [todo, setTodo] = useState([])
  const [entry, setEntry] = useState("")
  const [title, setTitle] = useState("")

  const insert = () => {
    let wole = { titleOne: title, entryOne: entry }
    setTodo([...todo, wole])
  }

  const deleteList = (i) => {
    todo.splice(i, 1)
    setTodo([...todo])
  }

  const editList = () => {

  }


  return (
    <main className="w-100 d-flex align-items-center justify-content-center flex-column" style={{ height: "100%" }}>
      <div className="card w-50">
        <input type="text" onChange={(i) => setTitle(i.target.value)} className="form control my-2" placeholder="Input entry title" />
        <input type="text" onChange={(i) => setEntry(i.target.value)} className="form control my-2" placeholder="Input new entry" />
        <button className={"btn btn-success my-2 w-25"} onClick={insert}>Add entry</button>
      </div>
      <div style={{ overflowY: "scroll" }} className="card w-50">
        {
          todo.map((item, i) =>
            <div key={i} className="my-2 card">

              <div>
                <h4>Entry title</h4>
                <p>{item.titleOne}</p>
              </div>

              <div>
                <h4>Entry body</h4>
                <p>{item.entryOne}</p>
              </div>
              <div>
                <button className={"btn btn-info w-50"}>Edit entry</button>
                <button onClick={() => deleteList(i)} className={"btn btn-danger w-50"}>Delete entry</button>
              </div>
            </div>
          )
        }
      </div>

    </main>
  );
}

export default App;
